#!/usr/bin/python3

link0= 70
link1=130
link2=127
link3=60
link4=110

offset0 = 90
offset1 = 75
offset2 = 90
offset3 = 90
offset4 = 90